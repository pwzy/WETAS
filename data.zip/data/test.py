import numpy as np
import os

# a = np.load('./EMG/train/1_raw_data_08-49_13.04.16.npy', allow_pickle=True)
# b = np.load('./EMG/train/1_raw_data_09-32_11.04.16.npy', allow_pickle=True)


# for root, dirs, files in os.walk('./EMG/valid/'):
for root, dirs, files in os.walk('./EMG/test/'):
    for file in files:
        if file.endswith('.npy'):
            a = np.load(os.path.join(root, file), allow_pickle=True)
            print(a[1].sum())


# print(a)
# print(a[1])
# print(a[1].sum())
# # np.savetxt('a1', a[1])

# print(b)

